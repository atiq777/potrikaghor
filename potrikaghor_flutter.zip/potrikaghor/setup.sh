#!/usr/bin/env bash
# Run once, inside this folder, on a computer with Flutter installed.
set -e

flutter create --org com.potrikaghor --project-name potrikaghor --platforms=android .
rm -f test/widget_test.dart

# Fixed signing key: every build is signed the same way, so a new APK
# installs directly over the old app (favourites & added papers are kept).
mkdir -p "$HOME/.android"
cp keystore/debug.keystore "$HOME/.android/debug.keystore"

# Also point Gradle's "debug" signing config at the same key explicitly
# (release builds are signed with it), so it never depends on the machine.
KS="$(pwd)/keystore/debug.keystore"
if [ -f android/app/build.gradle.kts ]; then
cat >> android/app/build.gradle.kts <<EOF

android {
    signingConfigs {
        getByName("debug") {
            storeFile = file("$KS")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
}
EOF
elif [ -f android/app/build.gradle ]; then
cat >> android/app/build.gradle <<EOF

android {
    signingConfigs {
        debug {
            storeFile file("$KS")
            storePassword "android"
            keyAlias "androiddebugkey"
            keyPassword "android"
        }
    }
}
EOF
fi

# App icon (newspaper logo) - replaces the default Flutter icon
R=android/app/src/main/res
for pair in mdpi:48 hdpi:72 xhdpi:96 xxhdpi:144 xxxhdpi:192; do
  d=${pair%%:*}; n=${pair##*:}
  if [ -f "icons/ic_$n.png" ]; then
    rm -f "$R/mipmap-$d"/ic_launcher.*
    cp "icons/ic_$n.png" "$R/mipmap-$d/ic_launcher.png"
  fi
done
rm -f "$R"/mipmap-anydpi*/ic_launcher.xml

M=android/app/src/main/AndroidManifest.xml

# App name on the home screen
perl -pi -e 's/android:label="[^"]*"/android:label="পত্রিকাঘর"/' "$M"

# Internet permission (needed in release builds) + link handling
if ! grep -q 'android.permission.INTERNET' "$M"; then
  perl -0pi -e 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <queries>\n        <intent>\n            <action android:name="android.intent.action.VIEW"/>\n            <data android:scheme="https"/>\n        </intent>\n    </queries>\n    <application#' "$M"
fi

flutter pub get
echo
echo "Done. Connect a phone and run:  flutter run"
echo "Build an APK with:              flutter build apk --release"
