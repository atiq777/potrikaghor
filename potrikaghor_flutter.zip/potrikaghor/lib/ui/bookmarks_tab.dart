import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../util.dart';
import 'widgets.dart';

class BookmarksTab extends StatelessWidget {
  const BookmarksTab({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final cs = Theme.of(context).colorScheme;
    final items = app.bookmarks;

    return CustomScrollView(
      slivers: [
        const SliverAppBar.large(title: Text('বুকমার্ক')),
        if (items.isEmpty)
          const SliverFillRemaining(
            hasScrollBody: false,
            child: EmptyState(
              icon: Icons.bookmark_outline_rounded,
              title: 'কোনো বুকমার্ক নেই',
              body: 'কোনো খবর পড়ার সময় উপরের বুকমার্ক আইকন চাপলে সেটি এখানে সেভ হবে।',
            ),
          )
        else
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, i) {
                final b = items[i];
                final paper = context.read<AppState>().paperFor(b.paperUrl) ?? Paper(b.title, '', b.paperUrl, 'all');
                final tag = 'bm-${b.url}';
                return Dismissible(
                  key: ValueKey('bm-${b.url}'),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    decoration: BoxDecoration(
                      color: cs.errorContainer,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 24),
                    child: Icon(Icons.delete_outline, color: cs.onErrorContainer),
                  ),
                  onDismissed: (_) {
                    app.removeBookmark(b.url);
                    toast(
                      context,
                      'বুকমার্ক সরানো হয়েছে',
                      action: SnackBarAction(
                        label: 'ফিরিয়ে আনুন',
                        onPressed: () => app.restoreBookmark(b, i),
                      ),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: Material(
                      color: cs.surfaceContainerLowest,
                      clipBehavior: Clip.antiAlias,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: BorderSide(color: cs.outlineVariant),
                      ),
                      child: InkWell(
                        onTap: () => openReader(context, paper, url: b.url, heroTag: tag),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            children: [
                              Hero(tag: tag, child: PaperAvatar(paper)),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      b.title,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: serif(size: 15.5, weight: FontWeight.w500, height: 1.4),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      '${paper.bn} · ${bnAgo(b.savedAt)}',
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall
                                          ?.copyWith(color: cs.onSurfaceVariant),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
              childCount: items.length,
            ),
          ),
        const SliverToBoxAdapter(child: SizedBox(height: 24)),
      ],
    );
  }
}
