import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../util.dart';
import 'fix_url_sheet.dart';
import 'share_card.dart';
import 'widgets.dart';

const _desktopUserAgent =
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/124.0.0.0 Safari/537.36';

class ReaderPage extends StatefulWidget {
  const ReaderPage({super.key, required this.paper, required this.url, this.heroTag});

  final Paper paper;
  final String url;
  final String? heroTag;

  @override
  State<ReaderPage> createState() => _ReaderPageState();
}

class _ReaderPageState extends State<ReaderPage> {
  late final WebViewController _c;
  int _progress = 0;
  bool _error = false;
  bool _revealed = false;
  bool _splashGone = false;
  bool _canBack = false;
  bool _canForward = false;
  String _url = '';
  late Paper _paper = widget.paper;

  @override
  void initState() {
    super.initState();
    _url = widget.url;
    final app = context.read<AppState>();

    _c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (u) {
          if (!mounted) return;
          setState(() {
            _url = u;
            _error = false;
          });
        },
        onProgress: (p) {
          if (!mounted) return;
          setState(() {
            _progress = p;
            if (p >= 65) _revealed = true;
          });
          if (p >= 35) _applyAdHide();
        },
        onPageFinished: (u) async {
          final back = await _c.canGoBack();
          final fwd = await _c.canGoForward();
          if (!mounted) return;
          setState(() {
            _revealed = true;
            _url = u;
            _canBack = back;
            _canForward = fwd;
          });
          _applyNight(context.read<AppState>().readerNight);
          _applyAdHide();
        },
        onWebResourceError: (e) {
          if (e.isForMainFrame == true && mounted) {
            setState(() {
              _error = true;
              _revealed = true;
            });
          }
        },
        onNavigationRequest: (r) {
          final uri = Uri.tryParse(r.url);
          if (uri == null) return NavigationDecision.navigate;
          const inApp = {'http', 'https', 'about', 'data', 'blob', 'file'};
          if (inApp.contains(uri.scheme)) return NavigationDecision.navigate;
          // mailto:, tel:, whatsapp:, intent: ... hand over to the system.
          launchUrl(uri, mode: LaunchMode.externalApplication);
          return NavigationDecision.prevent;
        },
      ));

    if (app.readerDesktop) _c.setUserAgent(_desktopUserAgent);
    _applyZoom(app.readerZoom);
    _c.loadRequest(Uri.parse(widget.url));

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) app.addRecent(widget.paper.url);
    });
  }

  void _applyZoom(int percent) {
    final p = _c.platform;
    if (p is AndroidWebViewController) p.setTextZoom(percent);
  }

  /// Hides common banner / floating ads with a stylesheet (best effort).
  static const _adHideJs =
      "(function(){if(document.getElementById('pg-ads'))return;var s=document.createElement('style');"
      "s.id='pg-ads';s.textContent='ins.adsbygoogle,.adsbygoogle,iframe[id^=\"google_ads\"],"
      "iframe[src*=\"doubleclick.net\"],iframe[src*=\"googlesyndication\"],iframe[src*=\"adservice\"],"
      "div[id^=\"div-gpt-ad\"],div[id^=\"google_ads\"],[id^=\"aswift_\"],.advertisement,.advert,"
      ".banner-ad,.sticky-ad,.floating-ad,.popup-ad,.ad-container,.ad-wrapper,.ad-slot,"
      "[class*=\"ad-banner\"],[id*=\"ad-banner\"]{display:none!important;height:0!important;"
      "min-height:0!important;visibility:hidden!important}';"
      "(document.head||document.documentElement).appendChild(s);})();";

  void _applyAdHide() {
    if (!context.read<AppState>().hideAds) return;
    _c.runJavaScript(_adHideJs);
  }

  Future<void> _openCard() async {
    final title = ((await _c.getTitle()) ?? '').trim();
    final url = (await _c.currentUrl()) ?? _url;
    if (!mounted) return;
    showShareCard(
      context,
      paper: widget.paper,
      title: title.isEmpty ? widget.paper.bn : title,
      url: url,
    );
  }

  void _applyNight(bool on) {
    _c.runJavaScript(
      "(function(){var id='pg-night';var e=document.getElementById(id);"
      "if($on){if(!e){e=document.createElement('style');e.id=id;"
      "e.textContent='html{filter:invert(1) hue-rotate(180deg)!important;background:#fff}"
      "img,video,picture,canvas,svg,iframe{filter:invert(1) hue-rotate(180deg)!important}';"
      "document.head.appendChild(e);}}else if(e){e.remove();}})();",
    );
  }

  Future<void> _toggleBookmark() async {
    final app = context.read<AppState>();
    final url = (await _c.currentUrl()) ?? _url;
    if (app.isBookmarked(url)) {
      app.removeBookmark(url);
      if (mounted) toast(context, 'বুকমার্ক সরানো হয়েছে');
    } else {
      final title = ((await _c.getTitle()) ?? '').trim();
      app.addBookmark(Bookmark(
        url: url,
        title: title.isEmpty ? widget.paper.bn : title,
        paperUrl: widget.paper.url,
        savedAt: DateTime.now().millisecondsSinceEpoch,
      ));
      if (mounted) toast(context, 'বুকমার্ক করা হয়েছে');
    }
    HapticFeedback.selectionClick();
  }

  Future<void> _share() async {
    final url = (await _c.currentUrl()) ?? _url;
    final title = ((await _c.getTitle()) ?? '').trim();
    await Share.share(title.isEmpty ? url : '$title\n$url');
  }

  Future<void> _fixLink() async {
    final p = await showFixLinkSheet(context, _paper);
    if (p == null || !mounted) return;
    setState(() => _paper = p);
    _c.loadRequest(Uri.parse(p.openUrl));
  }

  void _onMenu(String v) {
    final app = context.read<AppState>();
    switch (v) {
      case 'night':
        final next = !app.readerNight;
        app.setReaderNight(next);
        _applyNight(next);
      case 'desktop':
        final next = !app.readerDesktop;
        app.setReaderDesktop(next);
        _c.setUserAgent(next ? _desktopUserAgent : null);
        _c.reload();
      case 'zin':
        final z = (app.readerZoom + 10).clamp(70, 200);
        app.setReaderZoom(z);
        _applyZoom(z);
      case 'zout':
        final z = (app.readerZoom - 10).clamp(70, 200);
        app.setReaderZoom(z);
        _applyZoom(z);
      case 'card':
        _openCard();
      case 'copy':
        Clipboard.setData(ClipboardData(text: _url));
        toast(context, 'লিংক কপি হয়েছে');
      case 'browser':
        launchUrl(Uri.parse(_url), mode: LaunchMode.externalApplication);
      case 'fix':
        _fixLink();
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final cs = Theme.of(context).colorScheme;
    final marked = app.isBookmarked(_url);
    final loading = _progress < 100 && !_error;
    final avatar = PaperAvatar(widget.paper, size: 34);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await _c.canGoBack()) {
          await _c.goBack();
        } else if (mounted) {
          Navigator.of(context).pop();
        }
      },
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.close),
            tooltip: 'বন্ধ করুন',
            onPressed: () => Navigator.of(context).pop(),
          ),
          titleSpacing: 0,
          title: Row(
            children: [
              widget.heroTag == null ? avatar : Hero(tag: widget.heroTag!, child: avatar),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      widget.paper.bn,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: serif(size: 16.5, height: 1.25),
                    ),
                    Text(
                      widget.paper.host,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context)
                          .textTheme
                          .bodySmall
                          ?.copyWith(color: cs.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            IconButton(
              tooltip: marked ? 'বুকমার্ক সরান' : 'বুকমার্ক করুন',
              onPressed: _toggleBookmark,
              icon: AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
                child: Icon(
                  marked ? Icons.bookmark_rounded : Icons.bookmark_outline_rounded,
                  key: ValueKey(marked),
                  color: marked ? cs.primary : null,
                ),
              ),
            ),
            IconButton(
              tooltip: 'শেয়ার',
              icon: const Icon(Icons.ios_share_rounded),
              onPressed: _share,
            ),
            PopupMenuButton<String>(
              onSelected: _onMenu,
              itemBuilder: (_) => [
                CheckedPopupMenuItem(value: 'night', checked: app.readerNight, child: const Text('রাতের মোড')),
                CheckedPopupMenuItem(value: 'desktop', checked: app.readerDesktop, child: const Text('ডেস্কটপ সাইট')),
                const PopupMenuDivider(),
                PopupMenuItem(value: 'zin', child: Text('লেখা বড় করুন (${bnDigits(app.readerZoom)}%)')),
                const PopupMenuItem(value: 'zout', child: Text('লেখা ছোট করুন')),
                const PopupMenuDivider(),
                const PopupMenuItem(value: 'card', child: Text('শেয়ার কার্ড বানান')),
                const PopupMenuItem(value: 'copy', child: Text('লিংক কপি করুন')),
                const PopupMenuItem(value: 'browser', child: Text('ব্রাউজারে খুলুন')),
                const PopupMenuDivider(),
                const PopupMenuItem(value: 'fix', child: Text('এই পত্রিকার লিংক ঠিক করুন')),
              ],
            ),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(3),
            child: AnimatedOpacity(
              opacity: loading ? 1 : 0,
              duration: const Duration(milliseconds: 250),
              child: LinearProgressIndicator(
                value: _progress / 100,
                minHeight: 3,
                backgroundColor: Colors.transparent,
              ),
            ),
          ),
        ),
        body: Stack(
          children: [
            WebViewWidget(controller: _c),
            if (!_splashGone)
              Positioned.fill(
                child: IgnorePointer(
                  ignoring: _revealed,
                  child: AnimatedOpacity(
                    opacity: _revealed ? 0 : 1,
                    duration: const Duration(milliseconds: 350),
                    onEnd: () {
                      if (_revealed && mounted) setState(() => _splashGone = true);
                    },
                    child: _PulseLoader(widget.paper),
                  ),
                ),
              ),
            if (_error)
              Positioned.fill(
                child: ColoredBox(
                  color: Theme.of(context).scaffoldBackgroundColor,
                  child: EmptyState(
                    icon: Icons.cloud_off_rounded,
                    title: 'পেজ খোলা যায়নি',
                    body: 'ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন।',
                    actionLabel: 'আবার চেষ্টা করুন',
                    onAction: () {
                      setState(() => _error = false);
                      _c.loadRequest(Uri.parse(_url.isEmpty ? widget.url : _url));
                    },
                  ),
                ),
              ),
          ],
        ),
        bottomNavigationBar: BottomAppBar(
          height: 56,
          padding: EdgeInsets.zero,
          color: cs.surfaceContainerLowest,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              IconButton(
                tooltip: 'পেছনে',
                icon: const Icon(Icons.arrow_back_rounded),
                onPressed: _canBack ? () => _c.goBack() : null,
              ),
              IconButton(
                tooltip: 'সামনে',
                icon: const Icon(Icons.arrow_forward_rounded),
                onPressed: _canForward ? () => _c.goForward() : null,
              ),
              IconButton(
                tooltip: 'প্রথম পাতা',
                icon: const Icon(Icons.home_outlined),
                onPressed: () => _c.loadRequest(Uri.parse(_paper.openUrl)),
              ),
              IconButton(
                tooltip: 'রিলোড',
                icon: const Icon(Icons.refresh_rounded),
                onPressed: () => _c.reload(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


/// Shown while a newspaper opens: its logo gently pulses.
class _PulseLoader extends StatefulWidget {
  const _PulseLoader(this.paper);

  final Paper paper;

  @override
  State<_PulseLoader> createState() => _PulseLoaderState();
}

class _PulseLoaderState extends State<_PulseLoader> with SingleTickerProviderStateMixin {
  late final AnimationController _a = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  )..repeat();

  @override
  void dispose() {
    _a.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final bg = Theme.of(context).scaffoldBackgroundColor;
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: const Alignment(0, -0.15),
          radius: 0.95,
          colors: [cs.primary.withValues(alpha: 0.16), bg],
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedBuilder(
                      animation: _a,
                      builder: (_, child) {
                        final t = Curves.easeInOut.transform(
                          (_a.value < 0.5 ? _a.value : 1 - _a.value) * 2,
                        );
                        return SizedBox(
                          width: 150,
                          height: 150,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Container(
                                width: 112 + 26 * t,
                                height: 112 + 26 * t,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: cs.primary.withValues(alpha: 0.05 + 0.09 * t),
                                ),
                              ),
                              SizedBox(
                                width: 138,
                                height: 138,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.4,
                                  strokeCap: StrokeCap.round,
                                  color: cs.primary.withValues(alpha: 0.75),
                                  backgroundColor: cs.primary.withValues(alpha: 0.10),
                                ),
                              ),
                              Transform.scale(scale: 0.96 + 0.06 * t, child: child),
                            ],
                          ),
                        );
                      },
                      child: PaperAvatar(widget.paper, size: 84),
                    ),
                    const SizedBox(height: 26),
                    Text(widget.paper.bn, style: serif(size: 21, weight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text(
                      widget.paper.host,
                      style: Theme.of(context)
                          .textTheme
                          .bodySmall
                          ?.copyWith(color: cs.onSurfaceVariant),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'খুলছে…',
                      style: Theme.of(context)
                          .textTheme
                          .bodyMedium
                          ?.copyWith(color: cs.primary, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 22),
              child: Text.rich(
                const TextSpan(
                  text: 'পত্রিকাঘর',
                  children: [TextSpan(text: '.', style: TextStyle(color: flagRed))],
                ),
                style: serif(size: 15, weight: FontWeight.w600, color: cs.outline),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
