import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../news.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../util.dart';
import 'widgets.dart';

/// Which story was printed by how many newspapers.
class CoverageTab extends StatefulWidget {
  const CoverageTab({super.key});

  @override
  State<CoverageTab> createState() => _CoverageTabState();
}

class _CoverageTabState extends State<CoverageTab> with AutomaticKeepAliveClientMixin {
  bool _intl = false;
  final Map<bool, List<Coverage>> _cache = {};
  bool _loading = false;
  String? _error;
  int _req = 0;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool force = false}) async {
    final intl = _intl;
    if (!force && _cache.containsKey(intl)) {
      setState(() {
        _loading = false;
        _error = null;
      });
      return;
    }
    final id = ++_req;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await fetchCoverage(intl: intl);
      _cache[intl] = r;
      if (!mounted || id != _req) return;
      setState(() => _loading = false);
    } catch (_) {
      if (!mounted || id != _req) return;
      setState(() {
        _error = 'খবর আনা যায়নি। ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন।';
        _loading = false;
      });
    }
  }

  void _setIntl(bool v) {
    if (v == _intl) return;
    HapticFeedback.selectionClick();
    setState(() => _intl = v);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final cs = Theme.of(context).colorScheme;
    final list = _cache[_intl] ?? const <Coverage>[];
    final many = list.where((c) => c.count >= 3).take(30).toList();
    final few = list.where((c) => c.count == 2).take(10).toList();

    Widget body;
    if (_loading) {
      body = const Center(child: CircularProgressIndicator());
    } else if (_error != null) {
      body = EmptyState(
        icon: Icons.cloud_off_rounded,
        title: 'সংযোগ পাওয়া যায়নি',
        body: _error!,
        actionLabel: 'আবার চেষ্টা করুন',
        onAction: () => _load(force: true),
      );
    } else if (many.isEmpty && few.isEmpty) {
      body = EmptyState(
        icon: Icons.hub_outlined,
        title: 'কভারেজ পাওয়া যায়নি',
        body: 'এই মুহূর্তে একাধিক পত্রিকায় ছাপা খবর মেলেনি। একটু পরে আবার চেষ্টা করুন।',
        actionLabel: 'আবার আনুন',
        onAction: () => _load(force: true),
      );
    } else {
      body = RefreshIndicator(
        onRefresh: () => _load(force: true),
        child: ListView(
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            if (many.isNotEmpty)
              const Padding(
                padding: EdgeInsets.fromLTRB(20, 14, 20, 0),
                child: _SectionHead('বেশি পত্রিকায় ছাপা খবর'),
              ),
            for (final c in many) _CoverCard(c, onTap: () => _showDetail(c)),
            if (few.isNotEmpty) ...[
              const Padding(
                padding: EdgeInsets.fromLTRB(20, 22, 20, 0),
                child: _SectionHead('কম কাভার হওয়া খবর'),
              ),
              for (final c in few) _CoverCard(c, onTap: () => _showDetail(c)),
            ],
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
              child: Text(
                'Google News-এর তথ্য থেকে মেলানো। শুধু একটি পত্রিকায় ছাপা খবর এখানে দেখানো হয় না।',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: cs.onSurfaceVariant),
              ),
            ),
          ],
        ),
      );
    }

    return SafeArea(
      bottom: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            margin: const EdgeInsets.fromLTRB(20, 12, 20, 0),
            padding: const EdgeInsets.fromLTRB(0, 4, 0, 2),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(color: cs.onSurface, width: 3),
                bottom: BorderSide(color: cs.onSurface),
              ),
            ),
            child: Text.rich(
              const TextSpan(
                text: 'কভারেজ',
                children: [TextSpan(text: '.', style: TextStyle(color: flagRed))],
              ),
              style: serif(size: 36, weight: FontWeight.w900, height: 1.35),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
            child: Text(
              'কোন খবর কয়টি পত্রিকায় ছাপা হলো',
              style: Theme.of(context)
                  .textTheme
                  .bodySmall
                  ?.copyWith(color: cs.onSurfaceVariant),
            ),
          ),
          const SizedBox(height: 4),
          SizedBox(
            height: 46,
            child: DecoratedBox(
              decoration: BoxDecoration(
                border: Border(bottom: BorderSide(color: cs.outlineVariant)),
              ),
              child: Row(
                children: [
                  const SizedBox(width: 20),
                  _tab(cs, 'বাংলাদেশ', !_intl, () => _setIntl(false)),
                  const SizedBox(width: 22),
                  _tab(cs, 'আন্তর্জাতিক', _intl, () => _setIntl(true)),
                ],
              ),
            ),
          ),
          Expanded(child: body),
        ],
      ),
    );
  }

  Widget _tab(ColorScheme cs, String label, bool on, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(color: on ? cs.primary : Colors.transparent, width: 3),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 14.5,
            color: on ? cs.onSurface : cs.onSurfaceVariant,
            fontWeight: on ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
      ),
    );
  }

  void _showDetail(Coverage c) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      useSafeArea: true,
      builder: (ctx) => ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.82),
        child: _CoverDetail(c),
      ),
    );
  }
}

Paper _paperFor(AppState app, NewsItem n) {
  var h = Uri.tryParse(n.sourceUrl)?.host ?? '';
  if (h.startsWith('www.')) h = h.substring(4);
  if (h.isNotEmpty) {
    for (final p in app.allPapers) {
      if (p.host == h) return p;
    }
  }
  final name = n.source.trim().toLowerCase();
  for (final p in app.allPapers) {
    if (p.bn.toLowerCase() == name || (p.en.isNotEmpty && p.en.toLowerCase() == name)) return p;
  }
  return Paper(n.source, '', n.sourceUrl.isNotEmpty ? n.sourceUrl : n.link, 'online');
}

class _SectionHead extends StatelessWidget {
  const _SectionHead(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(width: 28, height: 3, color: Theme.of(context).colorScheme.primary),
        const SizedBox(height: 6),
        Text(text, style: serif(size: 19, weight: FontWeight.w700)),
      ],
    );
  }
}

class _CoverCard extends StatelessWidget {
  const _CoverCard(this.c, {required this.onTap});

  final Coverage c;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final app = context.watch<AppState>();
    final shown = c.items.take(4).toList();
    final more = c.count - shown.length;
    return InkWell(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: cs.outlineVariant)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: cs.primary,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                '${bnDigits(c.count)}টি পত্রিকায়',
                style: TextStyle(
                  color: cs.onPrimary,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              c.headline,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: serif(size: 18, weight: FontWeight.w700, height: 1.55),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                SizedBox(
                  width: 28 + 20.0 * (shown.length - 1),
                  height: 28,
                  child: Stack(
                    children: [
                      for (var i = 0; i < shown.length; i++)
                        Positioned(
                          left: i * 20.0,
                          child: PaperAvatar(_paperFor(app, shown[i]), size: 28),
                        ),
                    ],
                  ),
                ),
                if (more > 0) ...[
                  const SizedBox(width: 10),
                  Text(
                    'আরও ${bnDigits(more)}টি পত্রিকা',
                    style: Theme.of(context)
                        .textTheme
                        .bodySmall
                        ?.copyWith(color: cs.onSurfaceVariant),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _CoverDetail extends StatelessWidget {
  const _CoverDetail(this.c);

  final Coverage c;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final app = context.watch<AppState>();
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${bnDigits(c.count)}টি পত্রিকায় ছাপা',
                style: TextStyle(
                  color: cs.primary,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 4),
              Text(c.headline, style: serif(size: 19, weight: FontWeight.w900, height: 1.5)),
              const SizedBox(height: 10),
              Text(
                'কে কীভাবে শিরোনাম দিয়েছে',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: cs.onSurfaceVariant),
              ),
            ],
          ),
        ),
        Flexible(
          child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.only(bottom: 16),
            children: [
              for (final n in c.items) _row(context, app, n, cs),
            ],
          ),
        ),
      ],
    );
  }

  Widget _row(BuildContext context, AppState app, NewsItem n, ColorScheme cs) {
    final p = _paperFor(app, n);
    final t = n.time;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        border: Border(top: BorderSide(color: cs.outlineVariant)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          PaperAvatar(p, size: 40),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  t == null ? n.source : '${n.source} · ${bnAgo(t.millisecondsSinceEpoch)}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(color: cs.onSurfaceVariant),
                ),
                const SizedBox(height: 2),
                Text(
                  n.title,
                  maxLines: 4,
                  overflow: TextOverflow.ellipsis,
                  style: serif(size: 15.5, weight: FontWeight.w700, height: 1.5),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          OutlinedButton(
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(60, 44),
              padding: const EdgeInsets.symmetric(horizontal: 12),
            ),
            onPressed: () => openReader(context, p, url: n.link),
            child: const Text('পড়ুন'),
          ),
        ],
      ),
    );
  }
}
