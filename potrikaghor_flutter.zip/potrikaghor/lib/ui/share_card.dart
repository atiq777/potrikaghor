import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:share_plus/share_plus.dart';

import '../models.dart';
import '../theme.dart';
import '../util.dart';
import 'widgets.dart';

/// Preview a good-looking card for the current page and share it as an image.
Future<void> showShareCard(
  BuildContext context, {
  required Paper paper,
  required String title,
  required String url,
}) {
  return showDialog<void>(
    context: context,
    builder: (_) => _ShareCardDialog(paper: paper, title: title, url: url),
  );
}

class _ShareCardDialog extends StatefulWidget {
  const _ShareCardDialog({required this.paper, required this.title, required this.url});

  final Paper paper;
  final String title;
  final String url;

  @override
  State<_ShareCardDialog> createState() => _ShareCardDialogState();
}

class _ShareCardDialogState extends State<_ShareCardDialog> {
  final GlobalKey _key = GlobalKey();
  bool _busy = false;

  Future<void> _share() async {
    setState(() => _busy = true);
    try {
      final boundary = _key.currentContext!.findRenderObject()! as RenderRepaintBoundary;
      final image = await boundary.toImage(pixelRatio: 3);
      final data = await image.toByteData(format: ui.ImageByteFormat.png);
      if (data == null) throw Exception('no image');
      final file = File(
        '${Directory.systemTemp.path}/potrikaghor_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      await file.writeAsBytes(data.buffer.asUint8List());
      await Share.shareXFiles(
        [XFile(file.path, mimeType: 'image/png')],
        text: '${widget.title}\n${widget.url}',
      );
    } catch (_) {
      if (mounted) toast(context, 'কার্ড বানানো যায়নি, আবার চেষ্টা করুন');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final host = widget.paper.host;
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 22, vertical: 24),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RepaintBoundary(
              key: _key,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(26),
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF12855D), Color(0xFF0A3D2C)],
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        PaperAvatar(widget.paper, size: 46),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.paper.bn,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: serif(size: 17, color: Colors.white, weight: FontWeight.w700),
                              ),
                              Text(
                                host,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(color: Colors.white.withValues(alpha: 0.75), fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 22),
                    Icon(Icons.format_quote_rounded, color: Colors.white.withValues(alpha: 0.35), size: 34),
                    Text(
                      widget.title,
                      maxLines: 6,
                      overflow: TextOverflow.ellipsis,
                      style: serif(size: 21, color: Colors.white, weight: FontWeight.w600, height: 1.5),
                    ),
                    const SizedBox(height: 24),
                    Container(height: 1, color: Colors.white.withValues(alpha: 0.18)),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        const Icon(Icons.newspaper_rounded, color: Colors.white, size: 18),
                        const SizedBox(width: 8),
                        Text(
                          'পত্রিকাঘর দিয়ে পড়া',
                          style: serif(size: 13.5, color: Colors.white, weight: FontWeight.w600),
                        ),
                        const Spacer(),
                        Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(color: flagRed, shape: BoxShape.circle),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      side: const BorderSide(color: Colors.white54),
                      minimumSize: const Size.fromHeight(48),
                    ),
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('বন্ধ করুন'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                    onPressed: _busy ? null : _share,
                    icon: const Icon(Icons.ios_share_rounded),
                    label: Text(_busy ? 'অপেক্ষা…' : 'শেয়ার করুন'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
