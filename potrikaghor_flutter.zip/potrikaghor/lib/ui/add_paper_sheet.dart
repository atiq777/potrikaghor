import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../data/papers.dart';
import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../util.dart';
import 'widgets.dart';

/// Bottom sheet to add a new newspaper (or edit one the user added).
Future<void> showPaperSheet(BuildContext context, {Paper? edit}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    useSafeArea: true,
    builder: (_) => _PaperSheet(edit: edit),
  );
}

String? _normalize(String raw) {
  var s = raw.trim();
  if (s.isEmpty) return null;
  if (!s.startsWith('http://') && !s.startsWith('https://')) s = 'https://$s';
  if (s.endsWith('/')) s = s.substring(0, s.length - 1);
  final u = Uri.tryParse(s);
  if (u == null || !u.host.contains('.')) return null;
  return s;
}

class _PaperSheet extends StatefulWidget {
  const _PaperSheet({this.edit});

  final Paper? edit;

  @override
  State<_PaperSheet> createState() => _PaperSheetState();
}

class _PaperSheetState extends State<_PaperSheet> {
  late final TextEditingController _name = TextEditingController(text: widget.edit?.bn ?? '');
  late final TextEditingController _url = TextEditingController(text: widget.edit?.url ?? '');
  Timer? _debounce;
  String? _error;
  late String _cat = _initialCat();
  late String _previewName = _name.text.trim();
  late String? _previewUrl = _normalize(_url.text);

  String _initialCat() {
    final c = widget.edit?.cat;
    final ok = c != null && categories.any((x) => x.id == c && x.id != 'all');
    return ok ? c : 'online';
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _name.dispose();
    _url.dispose();
    super.dispose();
  }

  void _changed() {
    _error = null;
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 600), () {
      if (!mounted) return;
      setState(() {
        _previewName = _name.text.trim();
        _previewUrl = _normalize(_url.text);
      });
    });
    setState(() {});
  }

  void _save() {
    final app = context.read<AppState>();
    final name = _name.text.trim();
    final url = _normalize(_url.text);
    if (name.isEmpty) {
      setState(() => _error = 'পত্রিকার নাম লিখুন');
      return;
    }
    if (url == null) {
      setState(() => _error = 'সঠিক ওয়েবসাইট লিংক দিন (যেমন: www.prothomalo.com)');
      return;
    }
    final old = widget.edit;
    if ((old == null || old.url != url) && app.paperFor(url) != null) {
      setState(() => _error = 'এই লিংক আগে থেকেই তালিকায় আছে');
      return;
    }
    final paper = Paper(name, '', url, _cat, custom: true);
    if (old == null) {
      app.addCustom(paper);
    } else {
      app.updateCustom(old.url, paper);
    }
    HapticFeedback.mediumImpact();
    toast(context, old == null ? '${paper.bn} যোগ হয়েছে' : '${paper.bn} আপডেট হয়েছে');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final editing = widget.edit != null;
    final preview = Paper(
      _previewName.isEmpty ? 'ন' : _previewName,
      '',
      _previewUrl ?? '',
      'mine',
      custom: true,
    );

    return Padding(
      padding: EdgeInsets.fromLTRB(22, 0, 22, 22 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                PaperAvatar(preview, size: 60),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        editing ? 'পত্রিকা সম্পাদনা' : 'নতুন পত্রিকা যোগ করুন',
                        style: serif(size: 20, weight: FontWeight.w700),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'ওয়েবসাইটের লিংক দিলেই লোগো নিজে থেকে চলে আসবে।',
                        style: Theme.of(context)
                            .textTheme
                            .bodySmall
                            ?.copyWith(color: cs.onSurfaceVariant),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _name,
              onChanged: (_) => _changed(),
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: 'পত্রিকার নাম',
                hintText: 'যেমন: দৈনিক আমার শহর',
                prefixIcon: Icon(Icons.newspaper_rounded),
                border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(14))),
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _url,
              onChanged: (_) => _changed(),
              onSubmitted: (_) => _save(),
              keyboardType: TextInputType.url,
              autocorrect: false,
              textInputAction: TextInputAction.done,
              decoration: const InputDecoration(
                labelText: 'ওয়েবসাইট লিংক',
                hintText: 'www.example.com',
                prefixIcon: Icon(Icons.link_rounded),
                border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(14))),
              ),
            ),
            const SizedBox(height: 18),
            Text('কোন ক্যাটাগরিতে রাখবেন?', style: Theme.of(context).textTheme.labelLarge),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 0,
              children: [
                for (final c in categories.where((c) => c.id != 'all'))
                  ChoiceChip(
                    label: Text(c.label),
                    selected: _cat == c.id,
                    showCheckmark: false,
                    onSelected: (_) {
                      HapticFeedback.selectionClick();
                      setState(() => _cat = c.id);
                    },
                  ),
              ],
            ),
            AnimatedSize(
              duration: const Duration(milliseconds: 200),
              child: _error == null
                  ? const SizedBox(width: double.infinity)
                  : Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Row(
                        children: [
                          Icon(Icons.error_outline_rounded, size: 18, color: cs.error),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(_error!, style: TextStyle(color: cs.error, fontSize: 13)),
                          ),
                        ],
                      ),
                    ),
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: FilledButton.icon(
                onPressed: _save,
                icon: Icon(editing ? Icons.check_rounded : Icons.add_rounded),
                label: Text(editing ? 'সংরক্ষণ করুন' : 'তালিকায় যোগ করুন'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
