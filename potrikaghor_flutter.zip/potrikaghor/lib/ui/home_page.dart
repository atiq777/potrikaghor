import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../theme.dart';
import '../util.dart';
import 'add_paper_sheet.dart';
import 'bookmarks_tab.dart';
import 'compare_tab.dart';
import 'coverage_tab.dart';
import 'favorites_tab.dart';
import 'papers_tab.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _pages = PageController();
  int _index = 0;

  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  void _go(int i) => _pages.animateToPage(
        i,
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeOutCubic,
      );

  @override
  Widget build(BuildContext context) {
    final favCount = context.select<AppState, int>((s) => s.favs.length);
    final bmCount = context.select<AppState, int>((s) => s.bookmarks.length);

    return PopScope(
      canPop: _index == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _go(0);
      },
      child: Scaffold(
        body: PageView(
          controller: _pages,
          onPageChanged: (i) => setState(() => _index = i),
          children: const [PapersTab(), CompareTab(), CoverageTab(), FavoritesTab(), BookmarksTab()],
        ),
        floatingActionButton: _index == 0
            ? FloatingActionButton.extended(
                onPressed: () => showPaperSheet(context),
                icon: const Icon(Icons.add_rounded),
                label: const Text('পত্রিকা যোগ করুন'),
              )
            : null,
        bottomNavigationBar: SafeArea(
          minimum: const EdgeInsets.only(bottom: 10),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 6, 20, 4),
            child: _NavCapsule(
              index: _index,
              onTap: _go,
              items: [
                const _NavSpec(Icons.newspaper_outlined, Icons.newspaper, 'পত্রিকা'),
                const _NavSpec(Icons.bolt_outlined, Icons.bolt_rounded, 'শীর্ষ খবর'),
                const _NavSpec(Icons.hub_outlined, Icons.hub_rounded, 'কভারেজ'),
                _NavSpec(Icons.star_outline_rounded, Icons.star_rounded, 'প্রিয়', badge: favCount),
                _NavSpec(Icons.bookmark_outline_rounded, Icons.bookmark_rounded, 'বুকমার্ক',
                    badge: bmCount),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _NavSpec {
  const _NavSpec(this.icon, this.selectedIcon, this.label, {this.badge = 0});

  final IconData icon;
  final IconData selectedIcon;
  final String label;
  final int badge;
}

/// Floating dark capsule; the selected tab expands into a coloured pill.
class _NavCapsule extends StatelessWidget {
  const _NavCapsule({required this.index, required this.onTap, required this.items});

  final int index;
  final ValueChanged<int> onTap;
  final List<_NavSpec> items;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final bg = dark ? cs.surfaceContainerHigh : inkColor;
    return Container(
      height: 64,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(32),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.22),
            blurRadius: 18,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          for (var i = 0; i < items.length; i++) _item(context, i, cs),
        ],
      ),
    );
  }

  Widget _item(BuildContext context, int i, ColorScheme cs) {
    final it = items[i];
    final on = i == index;
    Widget icon = Icon(on ? it.selectedIcon : it.icon, size: 22, color: on ? cs.onPrimary : const Color(0xFFCFC6B4));
    if (it.badge > 0) {
      icon = Badge(label: Text(bnDigits(it.badge)), child: icon);
    }
    return Semantics(
      button: true,
      selected: on,
      label: it.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          HapticFeedback.selectionClick();
          onTap(i);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 260),
          curve: Curves.easeOutCubic,
          height: 44,
          constraints: const BoxConstraints(minWidth: 44),
          padding: EdgeInsets.symmetric(horizontal: on ? 16 : 0),
          decoration: BoxDecoration(
            color: on ? cs.primary : Colors.transparent,
            borderRadius: BorderRadius.circular(22),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              icon,
              if (on) ...[
                const SizedBox(width: 8),
                Text(
                  it.label,
                  style: TextStyle(
                    color: cs.onPrimary,
                    fontSize: 13.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
