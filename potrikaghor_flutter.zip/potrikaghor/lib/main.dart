import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'state/app_state.dart';
import 'theme.dart';
import 'ui/home_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final state = await AppState.load();
  runApp(ChangeNotifierProvider.value(value: state, child: const PotrikaGhor()));
}

class PotrikaGhor extends StatelessWidget {
  const PotrikaGhor({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final seed = accentColors[app.accent.clamp(0, accentColors.length - 1)];
    return MaterialApp(
      title: 'পত্রিকাঘর',
      debugShowCheckedModeBanner: false,
      themeMode: app.themeMode,
      theme: buildTheme(Brightness.light, seed: seed, style: app.themeStyle),
      darkTheme: buildTheme(Brightness.dark, seed: seed, style: app.themeStyle),
      builder: (context, child) {
        final mq = MediaQuery.of(context);
        return MediaQuery(
          data: mq.copyWith(textScaler: TextScaler.linear(app.textScale)),
          child: child!,
        );
      },
      home: const HomePage(),
    );
  }
}
