import 'dart:convert';
import 'dart:io';

/// One headline from Google News (RSS).
class NewsItem {
  const NewsItem({
    required this.title,
    required this.source,
    required this.sourceUrl,
    required this.link,
    this.time,
    this.related = const [],
  });

  final String title;
  final String source;
  final String sourceUrl;
  final String link;
  final DateTime? time;

  /// Other newspapers' headlines for the same story (Google groups them).
  final List<NewsItem> related;
}

/// Fetches headlines. Empty [query] = today's top headlines.
/// [intl] switches from the Bangladesh (Bangla) edition to the world (English) edition;
/// [section] is a Google News topic such as WORLD or BUSINESS (international only).
Future<List<NewsItem>> fetchNews({String query = '', bool intl = false, String section = ''}) async {
  final q = query.trim();
  final edition = intl
      ? {'hl': 'en-US', 'gl': 'US', 'ceid': 'US:en'}
      : {'hl': 'bn', 'gl': 'BD', 'ceid': 'BD:bn'};
  final Uri uri;
  if (intl && section.isNotEmpty) {
    uri = Uri.https('news.google.com', '/rss/headlines/section/topic/$section', edition);
  } else if (q.isEmpty) {
    uri = Uri.https('news.google.com', '/rss', edition);
  } else {
    uri = Uri.https('news.google.com', '/rss/search', {'q': q, ...edition});
  }

  final client = HttpClient()..connectionTimeout = const Duration(seconds: 12);
  try {
    final req = await client.getUrl(uri);
    req.headers.set(HttpHeaders.userAgentHeader, 'Mozilla/5.0 (Linux; Android 14) PotrikaGhor');
    final res = await req.close().timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) throw HttpException('status ${res.statusCode}');
    final body = await res.transform(utf8.decoder).join();
    return _parse(body);
  } finally {
    client.close();
  }
}

List<NewsItem> _parse(String xml) {
  final out = <NewsItem>[];
  for (final m in RegExp(r'<item>(.*?)</item>', dotAll: true).allMatches(xml)) {
    final b = m.group(1)!;
    var title = _text(b, 'title');
    final link = _text(b, 'link');
    final pub = _text(b, 'pubDate');
    final s = RegExp(r'<source[^>]*url="([^"]*)"[^>]*>(.*?)</source>', dotAll: true).firstMatch(b);
    final sourceUrl = s?.group(1) ?? '';
    final source = s == null ? '' : _unescape(s.group(2)!);
    final suffix = ' - $source';
    if (source.isNotEmpty && title.endsWith(suffix)) {
      title = title.substring(0, title.length - suffix.length);
    }
    if (title.isEmpty || link.isEmpty) continue;
    final related = <NewsItem>[];
    final desc = _text(b, 'description');
    for (final r in RegExp(r'<li[^>]*>(.*?)</li>', dotAll: true).allMatches(desc)) {
      final li = r.group(1)!;
      final a = RegExp(r'<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>', dotAll: true).firstMatch(li);
      final f = RegExp(r'<font[^>]*>(.*?)</font>', dotAll: true).firstMatch(li);
      if (a == null || f == null) continue;
      final rs = _unescape(_stripTags(f.group(1)!));
      var rt = _unescape(_stripTags(a.group(2)!));
      final suf = ' - $rs';
      if (rt.endsWith(suf)) rt = rt.substring(0, rt.length - suf.length);
      if (rt.isEmpty || rs.isEmpty) continue;
      related.add(NewsItem(
        title: rt,
        source: rs,
        sourceUrl: '',
        link: _unescape(a.group(1)!),
        time: _date(pub),
      ));
    }
    out.add(NewsItem(
      title: title,
      source: source.isEmpty ? 'অজানা উৎস' : source,
      sourceUrl: sourceUrl,
      link: link,
      time: _date(pub),
      related: related,
    ));
  }
  return out;
}

String _stripTags(String s) => s.replaceAll(RegExp(r'<[^>]*>'), '');

String _text(String block, String tag) {
  final m = RegExp('<$tag[^>]*>(.*?)</$tag>', dotAll: true).firstMatch(block);
  return m == null ? '' : _unescape(m.group(1)!);
}

String _unescape(String s) {
  var t = s.replaceAllMapped(
    RegExp(r'<!\[CDATA\[(.*?)\]\]>', dotAll: true),
    (m) => m.group(1)!,
  );
  t = t.replaceAllMapped(RegExp(r'&#(x?)([0-9a-fA-F]+);'), (m) {
    final code = int.tryParse(m.group(2)!, radix: m.group(1) == 'x' ? 16 : 10);
    return code == null ? m.group(0)! : String.fromCharCode(code);
  });
  t = t
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&quot;', '"')
      .replaceAll('&apos;', "'")
      .replaceAll('&amp;', '&');
  return t.trim();
}

DateTime? _date(String s) {
  if (s.isEmpty) return null;
  try {
    return HttpDate.parse(s);
  } catch (_) {
    return null;
  }
}

/// One story and the newspapers that covered it (one headline per newspaper).
class Coverage {
  Coverage(this.items);

  final List<NewsItem> items;

  String get headline => items.first.title;
  int get count => items.length;

  DateTime? get latest {
    DateTime? t;
    for (final i in items) {
      final x = i.time;
      if (x != null && (t == null || x.isAfter(t))) t = x;
    }
    return t;
  }
}

class _Group {
  final items = <NewsItem>[];
  final tokens = <Set<String>>[];
}

Set<String> _tokens(String s) => s
    .toLowerCase()
    .split(RegExp(r'[^\p{L}\p{M}\p{N}]+', unicode: true))
    .where((w) => w.runes.length >= 2)
    .toSet();

double _jaccard(Set<String> a, Set<String> b) {
  if (a.isEmpty || b.isEmpty) return 0;
  var inter = 0;
  for (final x in a) {
    if (b.contains(x)) inter++;
  }
  return inter / (a.length + b.length - inter);
}

/// Groups headlines about the same story: first by Google's own grouping,
/// then by how similar the headline words are.
List<Coverage> buildCoverage(List<NewsItem> all) {
  final groups = <_Group>[];
  final byTitle = <String, _Group>{};
  for (final n in all) {
    final tk = _tokens(n.title);
    _Group? hit = byTitle[n.title];
    if (hit == null && tk.length >= 3) {
      for (final g in groups) {
        if (g.tokens.any((t) => t.length >= 3 && _jaccard(t, tk) >= 0.55)) {
          hit = g;
          break;
        }
      }
    }
    if (hit == null) {
      hit = _Group();
      groups.add(hit);
    }
    hit.items
      ..add(n)
      ..addAll(n.related);
    hit.tokens.add(tk);
    byTitle[n.title] = hit;
    for (final r in n.related) {
      byTitle.putIfAbsent(r.title, () => hit!);
    }
  }

  final out = <Coverage>[];
  for (final g in groups) {
    final ordered = [
      ...g.items.where((i) => i.sourceUrl.isNotEmpty),
      ...g.items.where((i) => i.sourceUrl.isEmpty),
    ];
    final seen = <String>{};
    final uniq = <NewsItem>[];
    for (final it in ordered) {
      final k = it.source.trim().toLowerCase();
      if (k.isEmpty || k == 'অজানা উৎস') continue;
      if (seen.add(k)) uniq.add(it);
    }
    if (uniq.isNotEmpty) out.add(Coverage(uniq));
  }
  out.sort((a, b) {
    final c = b.count.compareTo(a.count);
    if (c != 0) return c;
    final ta = a.latest;
    final tb = b.latest;
    if (ta == null || tb == null) return 0;
    return tb.compareTo(ta);
  });
  return out;
}

/// Fetches several Google News feeds at once and groups them by story.
Future<List<Coverage>> fetchCoverage({required bool intl}) async {
  final topics = intl
      ? const ['', 'WORLD', 'BUSINESS', 'TECHNOLOGY', 'SPORTS', 'SCIENCE', 'HEALTH', 'ENTERTAINMENT']
      : const ['', 'রাজনীতি', 'ক্রিকেট', 'অর্থনীতি', 'বিনোদন', 'প্রযুক্তি', 'শিক্ষা', 'আবহাওয়া'];
  var failed = 0;
  final lists = await Future.wait(topics.map((t) async {
    try {
      if (intl) return await fetchNews(intl: true, section: t);
      return await fetchNews(query: t);
    } catch (_) {
      failed++;
      return <NewsItem>[];
    }
  }));
  if (failed == topics.length) throw const HttpException('no feeds');
  return buildCoverage([for (final l in lists) ...l]);
}
