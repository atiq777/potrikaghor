import 'package:flutter/material.dart';

const _digits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
const _weekdays = [
  'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার', 'রবিবার'
];
const _months = [
  'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
  'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
];

/// Converts 0-9 in any value to Bangla digits.
String bnDigits(Object v) => v
    .toString()
    .replaceAllMapped(RegExp(r'\d'), (m) => _digits[int.parse(m[0]!)]);

String bnToday() {
  final d = DateTime.now();
  return '${_weekdays[d.weekday - 1]}, ${bnDigits(d.day)} '
      '${_months[d.month - 1]} ${bnDigits(d.year)}';
}

String bnAgo(int millis) {
  final diff = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(millis));
  if (diff.inMinutes < 1) return 'এইমাত্র';
  if (diff.inHours < 1) return '${bnDigits(diff.inMinutes)} মিনিট আগে';
  if (diff.inDays < 1) return '${bnDigits(diff.inHours)} ঘণ্টা আগে';
  if (diff.inDays < 2) return 'গতকাল';
  if (diff.inDays < 30) return '${bnDigits(diff.inDays)} দিন আগে';
  return '${bnDigits((diff.inDays / 30).floor())} মাস আগে';
}

void toast(BuildContext context, String message, {SnackBarAction? action}) {
  final m = ScaffoldMessenger.of(context);
  m.clearSnackBars();
  m.showSnackBar(SnackBar(
    content: Text(message),
    behavior: SnackBarBehavior.floating,
    duration: const Duration(seconds: 3),
    action: action,
  ));
}
