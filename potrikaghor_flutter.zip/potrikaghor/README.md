# পত্রিকাঘর (Potrikaghor)

A Flutter newspaper app: about 100 Bangla, English, international and Kolkata
papers in 13 categories, read inside the app.

## Run it

You need Flutter 3.24 or newer.

    ./setup.sh          # Mac / Linux
    flutter run

On Windows, run these instead of setup.sh:

    flutter create --org com.potrikaghor --project-name potrikaghor --platforms=android .
    del test\widget_test.dart
    flutter pub get

Then open `android/app/src/main/AndroidManifest.xml` and:
1. Set `android:label="পত্রিকাঘর"`.
2. Add this line just above `<application`:
   `<uses-permission android:name="android.permission.INTERNET"/>`

Build an APK: `flutter build apk --release`

## Features

- Search and 13 category chips, with haptic feedback
- Swipe between Papers, Favorites and Bookmarks (or tap the bottom bar)
- Favorites: star a paper, drag to reorder, swipe to remove, undo
- "আবার পড়ুন" row with recently opened papers
- In-app reader: progress bar, back / forward / home / reload, error screen with retry
- Bookmark any article, share it, copy the link, open it in the browser
- Reader night mode, desktop site, text size
- Day / night / auto theme and app text size
- Smooth transitions: fade-and-rise reader, hero avatars, animated star and bookmark icons
- Android back button goes back inside a paper before closing it

## Edit the paper list

`lib/data/papers.dart`: add a line like
`Paper('বাংলা নাম', 'English name', 'https://site.com', 'bn')`.
Category ids: bn, en, online, intl, biz, sports, mag, edu, tech, jobs, kol, blog, local.

## Not included yet

- Breaking-news notifications need a server plus Firebase Cloud Messaging.
- Ads (AdMob) can be added with the `google_mobile_ads` package.
- App icon: add `flutter_launcher_icons`.

## Files

    lib/main.dart            app start, themes
    lib/theme.dart           colors and fonts
    lib/models.dart          Paper, Bookmark
    lib/data/papers.dart     the newspaper list
    lib/state/app_state.dart favorites, bookmarks, history, settings (saved on device)
    lib/ui/                  home, tabs, reader, settings, shared widgets

## নতুন ফিচার
- প্রতিটি পত্রিকার নামের পাশে ওয়েবসাইটের লোগো (ইন্টারনেট থাকলে)।
- নিচের "পত্রিকা যোগ করুন" বাটনে চেপে নিজের পছন্দের যেকোনো পত্রিকা/ওয়েবসাইট যোগ করা যায়; ⋮ মেনু থেকে সম্পাদনা বা মুছে ফেলা যায়।
- নতুন হোম ডিজাইন, অ্যাপ আইকন।

## আপডেট করার নিয়ম
নতুন সংস্করণ বানাতে pubspec.yaml-এর `version: 1.1.0+2` লাইনের শেষের সংখ্যা প্রতিবার ১ বাড়ান (+3, +4 ...)।
